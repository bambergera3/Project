SELECT *
FROM players
WHERE name LIKE :term