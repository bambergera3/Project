SELECT *
FROM players
WHERE playerid = :playerid